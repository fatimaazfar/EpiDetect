const PDFDocument = require('pdfkit');
const fs = require('fs');

async function generatePDF(user, prediction) {
  const doc = new PDFDocument();
  const pdfPath = `./reports/${user.id}-${Date.now()}.pdf`;

  doc.pipe(fs.createWriteStream(pdfPath));

  doc.fontSize(25).text('Skin Disease Report', { align: 'center' });
  doc.moveDown();
  doc.fontSize(18).text(`User: ${user.name}`);
  doc.text(`Email: ${user.email}`);
  doc.text(`Prediction: ${prediction}`);

  doc.end();

  return pdfPath;
}

module.exports = { generatePDF };
