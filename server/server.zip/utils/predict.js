const { exec } = require('child_process');
const path = require('path');

async function predictDisease(imagePath) {
  return new Promise((resolve, reject) => {
    const scriptPath = path.resolve(__dirname, '../predict.py');
    const command = `python ${scriptPath} ${imagePath}`;

    exec(command, (error, stdout, stderr) => {
      if (error) {
        console.error(`exec error: ${error}`);
        reject(error);
        return;
      }
      if (stderr) {
        console.error(`stderr: ${stderr}`);
        reject(stderr);
        return;
      }
      resolve(stdout.trim());
    });
  });
}

module.exports = { predictDisease };
