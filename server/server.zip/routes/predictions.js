const express = require('express');
const router = express.Router();
const auth = require('../middleware/auth');
const multer = require('multer');
const { predictDisease } = require('../utils/predict');
const { generatePDF } = require('../utils/pdf');
const User = require('../models/User');

// Multer setup for file upload
const storage = multer.diskStorage({
  destination: function (req, file, cb) {
    cb(null, './uploads/');
  },
  filename: function (req, file, cb) {
    cb(null, new Date().toISOString().replace(/:/g, '-') + file.originalname);
  }
});
const upload = multer({ storage: storage });

router.post('/predict', [auth, upload.single('image')], async (req, res) => {
  try {
    const imagePath = req.file.path;
    const prediction = await predictDisease(imagePath);
    
    const user = await User.findById(req.user.id);
    user.predictions.push({ image: imagePath, prediction });
    await user.save();

    const pdfPath = await generatePDF(user, prediction);

    res.json({ prediction, pdf: pdfPath });
  } catch (err) {
    console.error(err.message);
    res.status(500).send('Server error');
  }
});

module.exports = router;
